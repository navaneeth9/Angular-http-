import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OfferComponent } from './offer/offer.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/', pathMatch: 'full'
  },
  {
    path: '',
    component: OfferComponent,
    pathMatch: 'full'
  }
 // {
 //   path: '/offer',
 //   children: [
 //     { path: '', redirectTo: '/', pathMatch: 'full' },
 //     { path: '', component: OfferComponent },
 //     { path: 'expired', component: ExpiredComponent },
 //     { path: 'failed', component: IneligibleComponent }
 //   ]
 // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
