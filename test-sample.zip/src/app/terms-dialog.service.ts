import { Injectable } from '@angular/core';
import {Subject} from 'rxjs/Subject';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';

@Injectable()
export class TermsDialogService {
  private _status = new Subject<any>();
  private _removeDialog = new Subject<boolean>();
  showDialog: boolean = false;
  removeDialog: boolean = true;

  status = this._status.asObservable();
  constructor() { }

  toggle(showDialog?: boolean){
    console.log('TOGGLED', this.showDialog, this.removeDialog)
    this.showDialog = showDialog || !this.showDialog;
    this.removeDialog = !this.removeDialog;

    this._status.next({ showDialog: this.showDialog, removeDialog: this.removeDialog });
  }
}
