import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { HttpClient, HttpClientModule} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { DatePipe, DecimalPipe } from '@angular/common';
import { AnimationBuilder } from '@angular/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppSettings } from './app-settings.service';

import { AppComponent } from './app.component';
import { TermsDialogService } from './terms-dialog.service';
import { OfferComponent } from './offer/offer.component';
import { FooterNavComponent } from './footer-nav/footer-nav.component';
import { TermsDialogComponent } from './terms-dialog/terms-dialog.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, 'assets/il8n/', '.json');
}
@NgModule({
  declarations: [
    AppComponent,
    OfferComponent,
    FooterNavComponent,
    TermsDialogComponent
  ],
  imports: [
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    CommonModule,
    AppRoutingModule,
    BrowserModule,
    HttpModule,
    ReactiveFormsModule,
    RecaptchaModule.forRoot(),
    RecaptchaFormsModule ,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })],
  providers: [DatePipe, DecimalPipe, TermsDialogService, AppSettings], // Will use later , CampaignService],
  bootstrap: [AppComponent]
})
export class AppModule { }
