import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TermsDialogService } from '../terms-dialog.service';
//import { CampaignService } from '../campaign.service';

import { NavLink } from './nav-link';

@Component({
  selector: 'ch-footer-nav',
  templateUrl: './footer-nav.component.html',
  styleUrls: ['./footer-nav.component.scss']
})
export class FooterNavComponent implements OnInit {
  links: Array<NavLink> = [
    { url: '//united.com/', text: 'United' },
    { url: '//united.com/web/en-US/content/mileageplus/default.aspx', text: 'MileagePlus' },
    { url: '//united.com/web/en-US/content/mileageplus/rules/default.aspx', text: 'Mileageplus program rules' },
    { url: '//united.com/web/en-US/content/privacy.aspx', text: 'United privacy policy' },
  ];

  data: any = {};

  constructor(translate: TranslateService, private termsDialogService: TermsDialogService) { }// Will use later, private campaignService: CampaignService) { }

  ngOnInit() {
  // this.campaignService.getData.subscribe(data => {
  //   this.data = data;
  // })
  }
  toggleTerms(event) {
    event.preventDefault();
    this.termsDialogService.toggle();
  }

}
