export interface NavLink {
    text: string;
    url: string;
}
