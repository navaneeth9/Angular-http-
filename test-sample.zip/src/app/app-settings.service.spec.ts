import { TestBed, inject } from '@angular/core/testing';

import { AppSettings } from './app-settings.service';

describe('AppSettings', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppSettings]
    });
  });

  it('should be created', inject([AppSettings], (service: AppSettings) => {
    expect(service).toBeTruthy();
  }));
});
