import { TestBed, inject } from '@angular/core/testing';

import { TermsDialogService } from './terms-dialog.service';

describe('TermsDialogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TermsDialogService]
    });
  });

  it('should be created', inject([TermsDialogService], (service: TermsDialogService) => {
    expect(service).toBeTruthy();
  }));
});
