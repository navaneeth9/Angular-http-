import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AppSettings } from './app-settings.service';

@Component({
  selector: 'ch-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(translate: TranslateService,
    // Will use later private campaignService: CampaignService,
    private appSettings: AppSettings) {
    translate.setDefaultLang('en');
    translate.use('en');
  }
}
