import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { Subject } from 'rxjs/Subject';

import { TranslateService } from '@ngx-translate/core';

@Injectable()
export class AppSettings {
  readonly ENV: any = environment;

  constructor(private translate: TranslateService) {

  }
}
