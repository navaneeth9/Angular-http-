import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ch-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.scss']
})
export class OfferComponent implements OnInit {
  // Fake data for now... this will be mapped in the service
  data: any = {
    FIRST_NAME: 'Luke',
    LAST_NAME: 'Skywalker'
  };

  constructor() { }

  ngOnInit() {
  }

}
