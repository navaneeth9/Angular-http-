import { Component, OnInit } from '@angular/core';
import { TermsDialogService } from '../terms-dialog.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'ch-terms-dialog',
  templateUrl: './terms-dialog.component.html',
  styleUrls: ['./terms-dialog.component.scss']
})
export class TermsDialogComponent implements OnInit {
  data: any = {};
  showDialog: boolean = false;
  removeDialog: boolean = true;

  constructor(private termsDialogService:TermsDialogService) {
    termsDialogService.status.subscribe(data => {
        this.showDialog = data.showDialog;
        this.removeDialog = data.removeDialog;
    })
  }

  ngOnInit() {

  }

  toggle(showDialog?: boolean) {
    this.termsDialogService.toggle();
  }
}
