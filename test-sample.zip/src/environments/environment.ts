export const environment = {
  production: false,
  APP_ID: 'TBD',
  PROMO_CODE: 'TBD',
  NAME: 'dev',
  API_BASE_URL: 'http://localhost:4734/offers/api'
};
