export const environment = {
  production: true,
  APP_ID: 'TBD',
  PROMO_CODE: 'TBD',
  NAME: 'stage',
  API_BASE_URL: 'https://bigblue-stage.azurewebsites.net/offers/api'
};
