export const environment = {
  production: true,
  APP_ID: 'TBD',
  PROMO_CODE: 'TBD',
  NAME: 'prod',
  API_BASE_URL: 'https://promotions.united.com/offers/api'
};
